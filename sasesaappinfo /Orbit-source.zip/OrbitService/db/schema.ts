import { sqliteTable, text, integer, index } from "drizzle-orm/sqlite-core";
export const rooms = sqliteTable("orbit_rooms", {
  id: text("id").primaryKey(), revision: integer("revision").notNull(),
  snapshot: text("snapshot").notNull(), expiresAt: integer("expires_at").notNull(),
}, t => [index("rooms_expiry").on(t.expiresAt)]);
export const limits = sqliteTable("orbit_limits", {
  key: text("key").primaryKey(), count: integer("count").notNull(), expiresAt: integer("expires_at").notNull(),
}, t => [index("limits_expiry").on(t.expiresAt)]);
