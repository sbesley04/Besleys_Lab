import assert from 'node:assert/strict';
const base = process.argv[2];
if (!base || !/^https?:\/\//.test(base)) throw new Error('Pass the Orbit service origin.');
const uid = () => crypto.randomUUID().toUpperCase();
let passed = 0;
function check(condition, message) { assert.ok(condition, message); passed++; }
async function request(path, method='GET', body, credentials) {
  const headers = { 'Content-Type': 'application/json' };
  if (credentials) { headers.Authorization = `Bearer ${credentials.token}`; headers['X-Orbit-Member'] = credentials.memberID; }
  const r = await fetch(new URL(path, base), {method,headers,body:body ? JSON.stringify(body):undefined,redirect:'manual',signal:AbortSignal.timeout(30000)});
  const value = await r.json().catch(()=>({error:`Non-JSON status ${r.status}`}));
  return {status:r.status,value,cache:r.headers.get('cache-control')};
}
const host = {id:uid(),name:'QA Host'}, guest = {id:uid(),name:'QA Guest'};
let hc;
try {
  const created = await request('/api/rooms','POST',{title:'Orbit connection verification',profile:host,eventDate:Date.now()+7200000});
  check(created.status===200,`create: ${JSON.stringify(created.value)}`); hc=created.value.credentials;
  check(created.value.room.hostID===host.id,'host bound to profile');
  check(created.cache.includes('no-store'),'room response never cached');
  check(hc.token.length===64 && hc.inviteKey.length===64,'random member and invite capabilities');
  const path=`/api/rooms/${hc.roomID}`;
  let response=await request(path);check(response.status===400 || response.status===401,'anonymous denied');
  response=await request(path,'GET',undefined,{...hc,memberID:guest.id});check(response.status===403,'token cannot impersonate another member');
  response=await request('/api/join','POST',{roomID:hc.roomID,inviteKey:'f'.repeat(64),profile:guest});check(response.status===403,'wrong invitation denied');
  response=await request('/api/join','POST',{roomID:hc.roomID,inviteKey:hc.inviteKey,profile:guest});check(response.status===200,'guest requested entry');
  const gc=response.value.credentials;check(response.value.status==='pending' && !response.value.room,'pending guest receives no room content');
  response=await request(path,'POST',{id:uid(),kind:'chat',text:'Must be blocked'},gc);check(response.status===403,'pending guest cannot chat');
  response=await request(path,'GET',undefined,hc);check(response.value.pending[0].id===guest.id,'host sees approval request');
  response=await request(path,'POST',{id:uid(),kind:'approve',memberID:guest.id},hc);check(response.status===200,'host approval works');
  response=await request(path,'GET',undefined,gc);check(response.value.room.members.length===2 && !response.value.pending.length,'approved guest sees room, not host inbox');
  response=await request(path,'POST',{id:uid(),kind:'start'},gc);check(response.status===403,'guest cannot run host actions');
  const p1={id:uid(),title:'QA cafe',note:'Synthetic test option',category:'Food',address:'',url:''};
  const p2={...p1,id:uid(),title:'QA picnic'};
  await request(path,'POST',{id:uid(),kind:'suggest',place:p1},hc);
  response=await request(path,'POST',{id:uid(),kind:'suggest',place:p2},gc);check(response.value.room.places.length===2,'both clients can add suggestions');
  const chatID=uid();await request(path,'POST',{id:chatID,kind:'chat',text:'Idempotent test message'},gc);
  response=await request(path,'POST',{id:chatID,kind:'chat',text:'Idempotent test message'},gc);check(response.value.room.messages.filter(m=>m.text==='Idempotent test message').length===1,'repeated command does not duplicate message');
  const writes=Array.from({length:6},(_,i)=>request(path,'POST',{id:uid(),kind:'chat',text:`Concurrent ${i}`},i%2?hc:gc));
  const results=await Promise.all(writes);check(results.every(r=>r.status===200),'concurrent commands accepted');
  response=await request(path,'GET',undefined,hc);check(response.value.room.messages.filter(m=>m.text.startsWith('Concurrent')).length===6,'no concurrent message lost');
  response=await request(path,'POST',{id:uid(),kind:'start'},hc);check(response.value.room.phase==='voting','host starts voting');
  const revision=response.value.room.optionRevision;
  response=await request(path,'POST',{id:uid(),kind:'suggest',place:{...p1,id:uid()}},gc);check(response.status===409,'options frozen during voting');
  const ratings={[p1.id.toLowerCase()]:2,[p2.id.toLowerCase()]:-1};
  response=await request(path,'POST',{id:uid(),kind:'vote',ballot:{personID:host.id,optionRevision:revision,ratings}},gc);check(response.status===409,'guest cannot cast host ballot');
  response=await request(path,'POST',{id:uid(),kind:'vote',ballot:{personID:guest.id,optionRevision:revision,ratings:{[p1.id.toLowerCase()]:2}}},gc);check(response.status===400,'incomplete ballot rejected');
  response=await request(path,'POST',{id:uid(),kind:'vote',ballot:{personID:guest.id,optionRevision:revision,ratings}},gc);check(response.value.room.ballots.length===1,'guest ballot counted');
  response=await request(path,'POST',{id:uid(),kind:'choose',placeID:p1.id},hc);check(response.value.room.selectedPlaceID===p1.id,'host confirms selected plan');
  response=await request(path,'GET',undefined,gc);check(response.value.room.phase==='decided','other client receives decision');
  response=await request(path,'POST',{id:uid(),kind:'reopen'},hc);check(response.value.room.ballots.length===0 && response.value.room.optionRevision!==revision,'reopening clears old votes and rotates revision');
  response=await request(path,'DELETE',undefined,gc);check(response.status===403,'guest cannot delete room');
  const pending={id:uid(),name:'QA Pending'};
  response=await request('/api/join','POST',{roomID:hc.roomID,inviteKey:hc.inviteKey,profile:pending});
  const pc=response.value.credentials;
  response=await request(path,'POST',{id:uid(),kind:'leave'},pc);check(response.value.status==='left','pending guest can withdraw');
  response=await request(path,'POST',{id:uid(),kind:'leave'},gc);check(response.value.status==='left','guest can leave');
  response=await request(path,'GET',undefined,gc);check(response.status===403,'departed key loses access');
  response=await request(path,'DELETE',undefined,hc);check(response.value.status==='deleted','host deletes shared room');
  response=await request(path,'GET',undefined,hc);check(response.status===404,'deleted content inaccessible');
  hc=undefined;
  console.log(`PASS: ${passed} online checks across independent host and guest credentials.`);
} finally { if(hc) { const r=await request(`/api/rooms/${hc.roomID}`,'DELETE',undefined,hc); console.log(`Synthetic room cleanup status: ${r.status}`); } }
