"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowUpRight, CircleDot, MessageCircle, Plus, Users, Check, ArrowLeft, Copy, Send, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { type Credential, type RoomResponse, type Command, type Room, rankings } from "@/lib/model";
const makeID = () => crypto.randomUUID().toUpperCase();
const ratingLabels: [number,string,string][] = [[2,"Strong yes","↑"],[1,"Weak yes","→"],[-1,"Weak no","←"],[-2,"Strong no","↓"]];
const credentialKey = "orbit-device-room-v1";
export default function Home() {
  const [credential,setCredential] = useState<Credential|null>(null), [data,setData] = useState<RoomResponse|null>(null);
  const [name,setName] = useState(""), [title,setTitle] = useState("Friday, together"), [date,setDate] = useState("");
  const [invitation,setInvitation] = useState<{roomID:string;inviteKey:string}|null>(null), [busy,setBusy] = useState(false), [error,setError] = useState(""), [notice,setNotice] = useState("");
  const [message,setMessage] = useState(""), [option,setOption] = useState(""), [note,setNote] = useState("");
  const [ratings,setRatings] = useState<Record<string,number>>({}), [card,setCard] = useState(0), [editingVote,setEditingVote] = useState(false);
  const requestVersion = useRef(0), touch = useRef<{x:number;y:number}|null>(null);
  const visibleRoom = useRef<RoomResponse|null>(null);
  visibleRoom.current = data;
  useEffect(()=>{
    type Context = { registerTool(tool:{ name:string; description:string; inputSchema:object; annotations:{readOnlyHint:boolean;untrustedContentHint:boolean}; execute:(input:unknown)=>unknown },options:{signal:AbortSignal}):void|Promise<void> };
    const context = (document as Document & {modelContext?:Context}).modelContext;
    if(!context?.registerTool)return;
    const lifecycle = new AbortController();
    const tool = {name:"read_orbit_room",description:"Read the currently visible approved Orbit room and consensus. Does not send messages, vote, or reveal device access keys.",inputSchema:{type:"object",properties:{},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:true},execute(input:unknown){
      if(!input || typeof input!=="object" || Array.isArray(input) || Object.keys(input).length)throw new Error("Pass an empty object.");
      const state=visibleRoom.current;
      if(!state?.room)return {status:state?.status ?? "no_room"};
      return {status:state.status,room:structuredClone(state.room),pending:structuredClone(state.pending),expiresAt:state.expiresAt};
    }};
    try{void Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}
    return ()=>lifecycle.abort();
  },[]);
  const room = data?.room, host = room?.hostID === credential?.memberID;
  const refresh = useCallback(async (c:Credential, signal?:AbortSignal) => {
    const response = await fetch(`/api/rooms/${c.roomID}`,{headers:{Authorization:`Bearer ${c.token}`,"X-Orbit-Member":c.memberID},cache:"no-store",signal});
    const value = await response.json() as RoomResponse & {error?:string}; if(!response.ok) throw new Error(value.error ?? "Unable to refresh."); return value as RoomResponse;
  },[]);
  useEffect(()=>{
    const fragment = new URLSearchParams(location.hash.slice(1));
    if(fragment.get("room") && fragment.get("key")) setInvitation({roomID:fragment.get("room")!,inviteKey:fragment.get("key")!});
    try { const saved=localStorage.getItem(credentialKey); if(saved) { const c=JSON.parse(saved); if(c.roomID && c.memberID && c.token && (!fragment.get("room") || c.roomID===fragment.get("room")?.toUpperCase())) setCredential(c); } } catch { setNotice("This browser cannot remember access after you close it."); }
    const d = new Date(Date.now()+7200000); setDate(new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16));
  },[]);
  useEffect(()=>{
    if(!credential) return; let stopped=false; const controller = new AbortController();
    const poll=async()=>{if(document.hidden || stopped) return; const version=++requestVersion.current; try { const value=await refresh(credential,controller.signal); if(!stopped && version===requestVersion.current) {setData(value);setError("");} }catch(e){if(!stopped)setError(e instanceof Error ? e.message : "Connection interrupted.");}};
    void poll(); const interval=setInterval(poll,2500); document.addEventListener("visibilitychange",poll);
    return ()=>{stopped=true;controller.abort();clearInterval(interval);document.removeEventListener("visibilitychange",poll);requestVersion.current++;};
  },[credential,refresh]);
  useEffect(()=>{setRatings({});setCard(0);setEditingVote(false);},[room?.optionRevision]);
  async function begin() {
    setBusy(true);setError("");
    try {
      const profile={id:makeID(),name:name.trim()};
      const result=await fetch(invitation ? "/api/join" : "/api/rooms",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(invitation ? {...invitation,profile} : {title,profile,eventDate:new Date(date).getTime()})});
      const value=await result.json() as RoomResponse & {error?:string}; if(!result.ok)throw new Error(value.error);
      try{localStorage.setItem(credentialKey,JSON.stringify(value.credentials));}catch{setNotice("Keep this tab open: browser storage is unavailable.");}
      if(!value.credentials)throw new Error("The service did not return room access.");setCredential(value.credentials);setData(value);setInvitation(null);history.replaceState(null,"","/");
    }catch(e){setError(e instanceof Error ? e.message : "Unable to open this room.");}finally{setBusy(false);}
  }
  async function command(input:Omit<Command,"id">):Promise<boolean> {
    if(!credential)return false;setBusy(true);setError("");requestVersion.current++;
    try{
      const result=await fetch(`/api/rooms/${credential.roomID}`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${credential.token}`,"X-Orbit-Member":credential.memberID},body:JSON.stringify({id:makeID(),...input})});
      const value=await result.json() as RoomResponse & {error?:string};if(!result.ok)throw new Error(value.error);
      requestVersion.current++;setData(value);return true;
    }catch(e){setError(e instanceof Error ? `${e.message} If your connection dropped, check the refreshed room before sending again.` : "Unable to send.");return false;}finally{setBusy(false);}
  }
  async function leave() {
    if(!credential)return;setBusy(true);setError("");
    try {
      const response=await fetch(`/api/rooms/${credential.roomID}`,{method:host ? "DELETE":"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${credential.token}`,"X-Orbit-Member":credential.memberID},body:host ? undefined:JSON.stringify({id:makeID(),kind:"leave"})});
      if(!response.ok){const v=await response.json() as {error?:string};throw new Error(v.error);}
      forget();
    }catch(e){setError(e instanceof Error ? e.message : "Unable to leave.");}finally{setBusy(false);}
  }
  function forget(){requestVersion.current++;setCredential(null);setData(null);try{localStorage.removeItem(credentialKey);}catch{}setError("");}
  const inviteURL=credential?.inviteKey ? `${typeof location!=="undefined"?location.origin:""}/join#room=${credential.roomID}&key=${credential.inviteKey}` : "";
  const chosen=room?.places.find(p=>p.id===room.selectedPlaceID), ballot=room?.ballots.find(b=>b.personID===credential?.memberID), current=room?.places[card];
  function rate(value:number){if(!current)return;setRatings(v=>({...v,[current.id.toLowerCase()]:value}));setCard(v=>Math.min(v+1,room!.places.length));}
  return <main className="shell">
    <header className="brand"><CircleDot size={28}/><span>orbit</span><small>Make room for a plan.</small></header>
    {error && <div className="feedback error" role="alert">{error}</div>}
    {notice && <div className="feedback" role="status">{notice}<Button variant="ghost" size="sm" onClick={()=>setNotice("")}>Dismiss</Button></div>}
    {!credential ? <div className="welcome">
      <div><p className="eyebrow">PLAN WITH YOUR GROUP</p><h1>{invitation ? "Join your friends’ room." : "Start a shared planning room."}</h1><p className="intro">A room for the options, the conversation, and the decision. Suggest a few ideas, take a quick vote, and see where everyone lands.</p><div className="principles"><span><Users size={18}/> Up to eight people</span><span><MessageCircle size={18}/> Chat in the room</span><span><Check size={18}/> Four ways to vote</span></div></div>
      <section className="panel entry"><p className="eyebrow">{invitation ? "JOIN A PRIVATE ROOM" : "START SOMETHING"}</p><h2>{invitation ? "What should we call you?" : "What’s the plan?"}</h2>
        <form onSubmit={e=>{e.preventDefault();void begin();}}><label>Your display name<Input required maxLength={20} value={name} onChange={e=>setName(e.target.value)} placeholder="Alex" autoComplete="given-name"/></label>
          {!invitation && <><label>Room name<Input required maxLength={80} value={title} onChange={e=>setTitle(e.target.value)}/></label><label>When<Input type="datetime-local" required value={date} onChange={e=>setDate(e.target.value)}/></label></>}
          <Button className="wide" size="lg" disabled={busy || !name.trim()}>{busy ? "Connecting…" : invitation ? "Ask to join" : "Create a room"}<ArrowUpRight/></Button>
        </form><p className="small">{invitation ? "The host approves you before you can see the room." : "You’ll get a private invitation link. Approve each friend before they enter."} Rooms expire after seven days.</p>
        {invitation && <a className="textlink" href={`orbit://join?room=${encodeURIComponent(invitation.roomID)}&key=${encodeURIComponent(invitation.inviteKey)}`}>Open this invitation in Orbit for iPhone</a>}
      </section>
    </div> : !room ? <section className="panel pending"><Users size={36}/><h1>{data?.status==="pending" ? "You’re at the door." : "Opening your room…"}</h1><p>{data?.status==="pending" ? "The host needs to approve your request. This page will update automatically." : "Checking this device’s access."}</p><Button variant="outline" onClick={forget}>Clear access on this browser</Button><p className="small">Clearing a pending request here does not cancel it on the host’s screen.</p></section> : <>
      <div className="room-heading"><div><p className="eyebrow">{room.phase==="decided" ? "PLAN CONFIRMED" : room.phase==="voting" ? "FIND THE OVERLAP" : "GATHER A FEW OPTIONS"}</p><h1>{room.title}</h1><p>{new Date(room.eventDate).toLocaleString([], {weekday:"short",month:"short",day:"numeric",hour:"numeric",minute:"2-digit"})} · {room.members.length}/8 people</p></div><span className="status"><span/>Updates while this page is open</span></div>
      <div className="room-grid"><aside>
        <section className="panel"><h2>In the room</h2><div className="members">{room.members.map(m=><div key={m.id}><span className="avatar">{m.name.slice(0,1).toUpperCase()}</span><span>{m.name}{m.id===credential.memberID ? " (you)":""}<small>{m.id===room.hostID ? "Host" : room.ballots.some(b=>b.personID===m.id)?"Voted":"Member"}</small></span></div>)}</div>
          {!!inviteURL && <Button variant="outline" className="wide" onClick={async()=>{try{await navigator.clipboard.writeText(inviteURL);setNotice("Invitation copied. Share it only with people you want to join.");}catch{setNotice(inviteURL);}}}><Copy/>Copy invitation</Button>}
        </section>
        {data?.pending.length ? <section className="panel"><h2>At the door</h2>{data.pending.map(p=><div className="request" key={p.id}><strong>{p.name}</strong><div><Button disabled={busy} size="sm" onClick={()=>command({kind:"approve",memberID:p.id})}>Let in</Button><Button disabled={busy} size="sm" variant="ghost" onClick={()=>command({kind:"reject",memberID:p.id})}>Decline</Button></div></div>)}</section>:null}
        <p className="small">Only approved members can see this room. Voting is visible to the group. Expiry: {new Date(data!.expiresAt).toLocaleDateString()}. Keep your device access private.</p>
        <Dialog><DialogTrigger asChild><Button variant="ghost">{host?"Delete room":"Leave room"}</Button></DialogTrigger><DialogContent><DialogHeader><DialogTitle>{host?"Delete this room for everyone?":"Leave this room?"}</DialogTitle><DialogDescription>{host?"Chat, suggestions, and votes will be removed from the service. Copies on other devices may remain.":"Your device will lose access and your vote will be removed. Your previous messages remain in the conversation."}</DialogDescription></DialogHeader><Button variant="destructive" disabled={busy} onClick={leave}>Confirm {host?"deletion":"leaving"}</Button></DialogContent></Dialog>
      </aside><section className="workspace"><Tabs defaultValue="plan"><TabsList className="wide"><TabsTrigger value="plan">The plan</TabsTrigger><TabsTrigger value="chat">Conversation · {room.messages.length}</TabsTrigger></TabsList>
        <TabsContent value="plan">
          {room.phase==="collecting" && <><section className="panel"><div className="section-heading"><h2>A short list beats a long thread.</h2><span>{room.places.length}/12</span></div><p>Add places, activities, or anything else you’re deciding between.</p><form onSubmit={async e=>{e.preventDefault();if(await command({kind:"suggest",place:{id:makeID(),title:option,note,category:"Idea",address:"",url:""}})){setOption("");setNote("");}}}><label>Option<Input required maxLength={120} placeholder="e.g. Pizza by campus" value={option} onChange={e=>setOption(e.target.value)}/></label><label>A little context<Textarea maxLength={1000} placeholder="Cost, timing, or why it could work" value={note} onChange={e=>setNote(e.target.value)}/></label><Button disabled={busy || room.places.length>=12 || !option.trim()}><Plus/>Add option</Button></form></section>
          {room.places.map(p=><section className="panel option" key={p.id}><div><small>{p.category}</small><h3>{p.title}</h3><p>{p.note}</p>{p.address && <p className="small">{p.address}</p>}</div>{host && <Button variant="ghost" disabled={busy} onClick={()=>command({kind:"remove",placeID:p.id})}>Remove</Button>}</section>)}
          {host ? <Button className="wide" size="lg" disabled={busy || room.places.length<2} onClick={()=>command({kind:"start"})}>Start voting · {room.places.length} options</Button>:<p className="small">The host starts voting when the options are ready.</p>}</>}
          {room.phase==="voting" && <>{(!ballot || editingVote) ? <section className="panel voting"><p className="eyebrow">YOUR PREFERENCES</p>{current ? <><div className="progress"><span style={{width:`${card/room.places.length*100}%`}}/></div><p className="small">{card+1} of {room.places.length} · Swipe or tap a response</p><div className="swipe-card" onPointerDown={e=>{touch.current={x:e.clientX,y:e.clientY};}} onPointerUp={e=>{const start=touch.current;touch.current=null;if(!start)return;const dx=e.clientX-start.x,dy=e.clientY-start.y;if(Math.max(Math.abs(dx),Math.abs(dy))<45)return;rate(Math.abs(dx)>Math.abs(dy)?(dx>0?1:-1):(dy<0?2:-2));}}><small>{current.category}</small><h2>{current.title}</h2><p>{current.note}</p>{current.price!=null && <p className="small">Estimated cost: {current.price} · entered by a member</p>}</div><div className="ratings">{ratingLabels.map(([n,label,arrow])=><Button key={n} variant="outline" onClick={()=>rate(n)}><span>{arrow}</span>{label}</Button>)}</div></> : <><h2>Ready to share your preferences?</h2><p>Your response is only counted after you submit it.</p><Button disabled={busy || Object.keys(ratings).length!==room.places.length} onClick={async()=>{if(await command({kind:"vote",ballot:{personID:credential.memberID,optionRevision:room.optionRevision,ratings}}))setEditingVote(false);}}>Submit {room.places.length} responses</Button></>}{card>0 && <Button variant="ghost" onClick={()=>setCard(v=>Math.max(0,v-1))}><ArrowLeft/>Back one option</Button>}</section>:<section className="panel"><Check/><h2>Your vote is in.</h2><p>{room.ballots.length} of {room.members.length} people have responded.</p><Button variant="outline" onClick={()=>{setRatings(ballot.ratings);setCard(0);setEditingVote(true);}}>Change my responses</Button></section>}
          {!!room.ballots.length && <section className="panel"><h2>Where you overlap</h2><p className="small">Fewest strong objections first, then most yes votes, then total score. The host makes the final call.</p>{rankings(room).slice(0,3).map((r,i)=><div className="rank" key={r.place.id}><span className="rank-number">0{i+1}</span><div><h3>{r.place.title}</h3><p className="small">{r.yes} yes · {r.strongNo} strong no · {room.ballots.length} responses</p></div>{host && <Button disabled={busy} onClick={()=>command({kind:"choose",placeID:r.place.id})}>Choose</Button>}</div>)}</section>}
          {host && <Button variant="ghost" disabled={busy} onClick={()=>command({kind:"reopen"})}>Reopen options and clear votes</Button>}</>}
          {chosen && <section className="panel confirmed"><span className="confirmed-icon"><Check size={30}/></span><p className="eyebrow">YOU HAVE A PLAN</p><h2>{chosen.title}</h2><p>{chosen.note}</p><p>{new Date(room.eventDate).toLocaleString()}</p>{(chosen.address || chosen.latitude!=null) && <a className="textlink" target="_blank" rel="noreferrer" href={`https://maps.apple.com/?q=${encodeURIComponent(chosen.title)}${chosen.latitude!=null?`&ll=${chosen.latitude},${chosen.longitude}`:`&address=${encodeURIComponent(chosen.address)}`}`}><MapPin size={18}/>Open in Apple Maps</a>}<p className="small">Open Orbit on iPhone to add this plan to Calendar, Reminders, or a local notification.</p>{host && <Button variant="outline" disabled={busy} onClick={()=>command({kind:"reopen"})}>Reopen the decision</Button>}</section>}
        </TabsContent>
        <TabsContent value="chat"><section className="panel chat"><h2>Keep the conversation here.</h2><p className="small">Visible to everyone approved for this room. Older messages are trimmed as the room fills up.</p><div className="messages" aria-live="polite">{room.messages.length ? room.messages.map(m=><div className={`message ${m.personID===credential.memberID?"own":""}`} key={m.id}><small>{m.name} · {new Date(m.createdAt).toLocaleTimeString([],{hour:"numeric",minute:"2-digit"})}</small><p>{m.text}</p></div>):<p>No messages yet. Start with the detail everyone needs to know.</p>}</div><form onSubmit={async e=>{e.preventDefault();if(await command({kind:"chat",text:message}))setMessage("");}}><label>Message<Textarea required maxLength={1000} value={message} onChange={e=>setMessage(e.target.value)} placeholder="Any timing or budget constraints?"/></label><Button disabled={busy || !message.trim()}><Send/>Send</Button></form></section></TabsContent>
      </Tabs></section></div></>}
    <footer><CircleDot size={18}/><span>Orbit · A place to agree.</span><Dialog><DialogTrigger asChild><Button variant="link">Privacy & how it works</Button></DialogTrigger><DialogContent><DialogHeader><DialogTitle>A small, temporary shared space.</DialogTitle><DialogDescription>Rooms use random device keys and private invitations, with host approval. Display names are chosen by participants and are not verified identities.</DialogDescription></DialogHeader><div className="privacy-copy"><p>The service stores the name you choose, a random member identifier, messages, votes, and the ideas or place details you deliberately add. All approved members can see this shared content. Private photos, your contacts, and your saved iPhone library are not uploaded.</p><p>Rooms become inaccessible after seven days. Expired data is removed when the service next processes a create or join request. Hosts can delete a room earlier. Device copies may remain after server deletion. No analytics or advertising trackers are installed.</p><p>This browser remembers its room access key locally; the room itself is stored on the service. Don’t use a shared browser for private conversations. Clearing browser storage loses access. Live updates run while this page is visible; there are no background message notifications.</p></div></DialogContent></Dialog></footer>
  </main>;
}
