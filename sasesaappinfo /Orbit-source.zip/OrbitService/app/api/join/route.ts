import { join, handle } from "@/lib/service";
export const POST = (request: Request) => handle(()=>join(request));
