import { state, command, remove, handle } from "@/lib/service";
type Context = { params: Promise<{id:string}> };
export const GET = (r:Request,c:Context) => handle(async()=>state(r,(await c.params).id));
export const POST = (r:Request,c:Context) => handle(async()=>command(r,(await c.params).id));
export const DELETE = (r:Request,c:Context) => handle(async()=>remove(r,(await c.params).id));
