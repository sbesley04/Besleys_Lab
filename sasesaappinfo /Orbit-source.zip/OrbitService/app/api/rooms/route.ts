import { create, handle } from "@/lib/service";
export const POST = (request: Request) => handle(()=>create(request));
