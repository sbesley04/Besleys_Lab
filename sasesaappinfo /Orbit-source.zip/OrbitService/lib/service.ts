import { env } from "cloudflare:workers";
import { apply, Failure, id, person, text, uuid, type Command, type Credential, type Person, type Room, type RoomResponse } from "./model";
type Access = { person: Person; hash: string; state: "active" | "pending" | "denied" };
type Record = { room: Room; access: Access[]; inviteHash: string; expiresAt: number };
const db = () => { if (!env.DB) throw new Failure("The online service is unavailable. Try again shortly.", 503); return env.DB; };
const token = () => Array.from(crypto.getRandomValues(new Uint8Array(32)), n => n.toString(16).padStart(2,"0")).join("");
const hash = async (s: string) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s))), n => n.toString(16).padStart(2,"0")).join("");
async function cleanup() { await db().batch([db().prepare("DELETE FROM orbit_rooms WHERE expires_at <= ?").bind(Date.now()), db().prepare("DELETE FROM orbit_limits WHERE expires_at <= ?").bind(Date.now())]); }
async function limit(request: Request, group: string, maximum: number) {
  const minute = Math.floor(Date.now()/60000), address = request.headers.get("cf-connecting-ip") ?? "shared";
  const key = await hash(`${group}:${address}:${minute}`);
  const result = await db().prepare("INSERT INTO orbit_limits (key,count,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count").bind(key,(minute+2)*60000).first<{count:number}>();
  if ((result?.count ?? maximum+1) > maximum) throw new Failure("Too many requests. Try again in a minute.", 429);
}
export async function body<T>(request: Request): Promise<T> {
  if (!request.headers.get("content-type")?.includes("application/json")) throw new Failure("Send JSON content.", 415);
  const reader = request.body?.getReader(); if (!reader) throw new Failure("Missing request body.");
  const chunks: Uint8Array[] = []; let size = 0;
  while (true) { const v = await reader.read(); if (v.done) break; size += v.value.length; if (size > 32000) { await reader.cancel(); throw new Failure("This request is too large.", 413); } chunks.push(v.value); }
  const bytes = new Uint8Array(size); let offset = 0; for (const c of chunks) { bytes.set(c,offset); offset += c.length; }
  try { const v = JSON.parse(new TextDecoder().decode(bytes)); if (!v || typeof v !== "object" || Array.isArray(v)) throw 0; return v; } catch { throw new Failure("Invalid JSON content."); }
}
async function read(roomID: string): Promise<Record> {
  const row = await db().prepare("SELECT snapshot FROM orbit_rooms WHERE id = ? AND expires_at > ?").bind(id(roomID),Date.now()).first<{snapshot:string}>();
  if (!row) throw new Failure("This room expired or was deleted. Ask for a new invitation.",404);
  return JSON.parse(row.snapshot);
}
async function auth(request: Request, record: Record): Promise<Access> {
  const memberID = id(request.headers.get("x-orbit-member"));
  const bearer = request.headers.get("authorization")?.match(/^Bearer ([a-f0-9]{64})$/)?.[1];
  if (!bearer) throw new Failure("This device is not signed into the room. Use your invitation.",401);
  const access = record.access.find(a => a.person.id === memberID && a.state !== "denied");
  if (!access || access.hash !== await hash(bearer)) throw new Failure("Room access was removed or this device key is invalid.",403);
  return access;
}
function response(record: Record, access: Access, credentials?: Credential): RoomResponse {
  const active = access.state === "active";
  return { status: active ? "active" : "pending", room: active ? record.room : undefined, pending: active && access.person.id === record.room.hostID ? record.access.filter(a=>a.state === "pending").map(a=>a.person) : [], credentials, expiresAt: record.expiresAt };
}
async function write(record: Record, oldRevision: number) {
  const result = await db().prepare("UPDATE orbit_rooms SET snapshot = ?, revision = ? WHERE id = ? AND revision = ? AND expires_at > ?").bind(JSON.stringify(record),record.room.revision,record.room.id,oldRevision,Date.now()).run();
  return result.meta.changes === 1;
}
export async function create(request: Request) {
  await cleanup(); await limit(request,"create",12);
  const input = await body<{title:string;profile:Person;eventDate:number}>(request), p = person(input.profile);
  if (!Number.isFinite(input.eventDate) || input.eventDate < Date.now()-60000 || input.eventDate > Date.now()+366*86400000) throw new Failure("Choose a plan time within the next year.");
  const secret = token(), inviteKey = token();
  const room: Room = { id: uuid(), title: text(input.title,80), hostID:p.id, revision:1, optionRevision:uuid(), phase:"collecting", members:[p], places:[], ballots:[], messages:[], eventDate:input.eventDate, createdAt:Date.now(), appliedIDs:[] };
  const access: Access = {person:p,hash:await hash(secret),state:"active"};
  const record: Record = {room,access:[access],inviteHash:await hash(inviteKey),expiresAt:Date.now()+7*86400000};
  await db().prepare("INSERT INTO orbit_rooms (id,revision,snapshot,expires_at) VALUES (?,?,?,?)").bind(room.id,1,JSON.stringify(record),record.expiresAt).run();
  return response(record,access,{roomID:room.id,memberID:p.id,token:secret,inviteKey});
}
export async function join(request: Request) {
  await cleanup(); await limit(request,"join",30);
  const input = await body<{roomID:string;inviteKey:string;profile:Person}>(request), p = person(input.profile);
  if (typeof input.inviteKey !== "string" || !/^[a-f0-9]{64}$/.test(input.inviteKey)) throw new Failure("This invitation is incomplete.",403);
  const invitationHash = await hash(input.inviteKey), secret = token(), access: Access = {person:p,hash:await hash(secret),state:"pending"};
  for (let attempt=0;attempt<5;attempt++) {
    const record = await read(input.roomID), previous = record.room.revision;
    if (record.inviteHash !== invitationHash) throw new Failure("This invitation is invalid.",403);
    if (record.access.some(a=>a.person.id === p.id)) throw new Failure("This device already requested access. Reopen its existing room, or use another device.",409);
    if (record.access.length >= 32 || record.access.filter(a=>a.state !== "denied").length >= 8) throw new Failure("This room is full (eight people including the host).",409);
    record.access.push(access); record.room.revision++;
    if (await write(record,previous)) return response(record,access,{roomID:record.room.id,memberID:p.id,token:secret});
  }
  throw new Failure("The room changed. Try joining again.",409);
}
export async function state(request: Request, roomID: string) { const r = await read(roomID); return response(r,await auth(request,r)); }
export async function command(request: Request, roomID: string) {
  const input = await body<Command>(request); id(input.id); await limit(request,"write",240);
  for (let attempt=0;attempt<6;attempt++) {
    const r = await read(roomID), access = await auth(request,r), previous = r.room.revision;
    if (access.state !== "active" && input.kind !== "leave") throw new Failure("Wait for the host to approve your request.",403);
    if (r.room.appliedIDs.includes(id(input.id))) return response(r,access);
    if (["approve","reject"].includes(input.kind)) {
      if (access.person.id !== r.room.hostID) throw new Failure("Only the host can approve guests.",403);
      const pending = r.access.find(a => a.person.id === id(input.memberID) && a.state === "pending");
      if (!pending) throw new Failure("This request was already handled.",409);
      pending.state = input.kind === "approve" ? "active" : "denied";
      if (pending.state === "active") r.room.members.push(pending.person);
      r.room.appliedIDs = [...r.room.appliedIDs,id(input.id)].slice(-200); r.room.revision++;
    } else if (input.kind === "leave") {
      if (access.person.id === r.room.hostID) throw new Failure("The host must delete the room instead.");
      r.room.members = r.room.members.filter(m=>m.id !== access.person.id); r.room.ballots = r.room.ballots.filter(b=>b.personID !== access.person.id); access.state = "denied"; r.room.revision++;
    } else { r.room = apply(r.room,input,access.person.id); }
    if (await write(r,previous)) return input.kind === "leave" ? {status:"left"} : response(r,access);
  }
  throw new Failure("Several people updated the room at once. Try again.",409);
}
export async function remove(request: Request, roomID: string) {
  const r = await read(roomID), access = await auth(request,r);
  if (access.person.id !== r.room.hostID || access.state !== "active") throw new Failure("Only the host can delete this room.",403);
  await db().prepare("DELETE FROM orbit_rooms WHERE id = ?").bind(r.room.id).run(); return {status:"deleted"};
}
export async function handle(fn:()=>Promise<unknown>) {
  const headers = {"Cache-Control":"no-store, private","Content-Type":"application/json","X-Content-Type-Options":"nosniff","Referrer-Policy":"no-referrer"};
  try { return Response.json(await fn(),{headers}); } catch(e) {
    if (!(e instanceof Failure)) console.error("Orbit request failed", e instanceof Error ? e.message : "Unknown error");
    return Response.json({error:e instanceof Failure ? e.message : "The online service is unavailable. Your last confirmed room is safe; try again."},{status:e instanceof Failure ? e.status : 503,headers});
  }
}
