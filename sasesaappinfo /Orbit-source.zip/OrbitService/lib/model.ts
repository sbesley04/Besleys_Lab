export type Person = { id: string; name: string };
export type Place = { id: string; title: string; note: string; category: string; address: string; url: string; latitude?: number; longitude?: number; price?: number };
export type Ballot = { personID: string; optionRevision: string; ratings: Record<string, number> };
export type Message = { id: string; personID: string; name: string; text: string; createdAt: number };
export type Room = { id: string; title: string; hostID: string; revision: number; optionRevision: string; phase: string; members: Person[]; places: Place[]; ballots: Ballot[]; messages: Message[]; selectedPlaceID?: string; eventDate: number; createdAt: number; appliedIDs: string[] };
export type Command = { id: string; kind: string; text?: string; place?: Place; ballot?: Ballot; placeID?: string; memberID?: string };
export type Credential = { roomID: string; memberID: string; token: string; inviteKey?: string };
export type RoomResponse = { status: "active" | "pending"; room?: Room; pending: Person[]; credentials?: Credential; expiresAt: number };
export class Failure extends Error { constructor(message: string, public status = 400) { super(message); } }
export const uuid = () => crypto.randomUUID().toUpperCase();
export function id(value: unknown): string {
  if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) throw new Failure("Invalid room or member identifier.");
  return value.toUpperCase();
}
export function text(value: unknown, max: number, optional = false): string {
  if (typeof value !== "string" || Array.from(value).length > max || (!optional && !value.trim())) throw new Failure(`Use between ${optional ? 0 : 1} and ${max} characters.`);
  return value.trim();
}
export function person(value: Person): Person { if (!value) throw new Failure("Choose a display name."); return { id: id(value.id), name: text(value.name, 20) }; }
export function place(value: Place): Place {
  if (!value) throw new Failure("Add an option first.");
  const p: Place = { id: id(value.id), title: text(value.title, 120), note: text(value.note ?? "", 1000, true), category: text(value.category ?? "Place", 80, true), address: text(value.address ?? "", 500, true), url: text(value.url ?? "", 2000, true) };
  if (p.url) { try { const u = new URL(p.url); if (!["https:", "http:"].includes(u.protocol)) throw 0; } catch { throw new Failure("Use an http or https link."); } }
  if (value.latitude != null || value.longitude != null) {
    if (typeof value.latitude !== "number" || typeof value.longitude !== "number" || !Number.isFinite(value.latitude) || !Number.isFinite(value.longitude) || Math.abs(value.latitude) > 90 || Math.abs(value.longitude) > 180) throw new Failure("Invalid place coordinates.");
    p.latitude = value.latitude; p.longitude = value.longitude;
  }
  if (value.price != null) { if (!Number.isInteger(value.price) || value.price < 0 || value.price > 100000) throw new Failure("Invalid price estimate."); p.price = value.price; }
  return p;
}
export function apply(room: Room, input: Command, memberID: string): Room {
  const r = structuredClone(room), commandID = id(input.id), who = r.members.find(m => m.id === memberID);
  if (!who) throw new Failure("Host approval is required.", 403);
  if (r.appliedIDs.includes(commandID)) return r;
  const host = () => { if (r.hostID !== memberID) throw new Failure("Only the host can do that.", 403); };
  switch (input.kind) {
    case "chat": r.messages.push({ id: uuid(), personID: who.id, name: who.name, text: text(input.text, 1000), createdAt: Date.now() }); break;
    case "suggest": {
      if (r.phase !== "collecting" || r.places.length >= 12) throw new Failure("Suggestions are closed for this round.", 409);
      const p = place(input.place!); if (r.places.some(x => x.id === p.id)) throw new Failure("This option is already in the room.", 409);
      r.places.push(p); break;
    }
    case "vote": {
      const b = input.ballot;
      if (r.phase !== "voting" || !b || id(b.personID) !== memberID || id(b.optionRevision) !== r.optionRevision || !b.ratings || typeof b.ratings !== "object" || Array.isArray(b.ratings)) throw new Failure("Voting changed. Refresh and try again.", 409);
      const keys = r.places.map(p => p.id.toLowerCase());
      if (Object.keys(b.ratings).length !== keys.length || keys.some(k => ![-2, -1, 1, 2].includes(b.ratings[k]))) throw new Failure("Rate every option before submitting.");
      r.ballots = r.ballots.filter(v => v.personID !== memberID); r.ballots.push({ personID: memberID, optionRevision: r.optionRevision, ratings: b.ratings }); break;
    }
    case "start": host(); if (r.phase !== "collecting" || r.places.length < 2) throw new Failure("Add at least two options before voting.", 409); r.phase = "voting"; break;
    case "choose": host(); if (r.phase !== "voting" || !r.ballots.length || !r.places.some(p => p.id === id(input.placeID))) throw new Failure("Choose an option after someone votes.", 409); r.selectedPlaceID = id(input.placeID); r.phase = "decided"; break;
    case "reopen": host(); r.phase = "collecting"; r.optionRevision = uuid(); r.ballots = []; delete r.selectedPlaceID; break;
    case "remove": host(); if (r.phase !== "collecting") throw new Failure("Reopen suggestions before removing an option.", 409); r.places = r.places.filter(p => p.id !== id(input.placeID)); break;
    default: throw new Failure("Unsupported action. Update Orbit and try again.");
  }
  r.appliedIDs = [...r.appliedIDs, commandID].slice(-200); r.messages = r.messages.slice(-200); r.revision++;
  while (r.messages.length > 1 && new TextEncoder().encode(JSON.stringify(r)).length > 220000) r.messages.shift();
  return r;
}
export function rankings(r: Room) {
  return r.places.map(p => { const votes = r.ballots.map(b => b.ratings[p.id.toLowerCase()]).filter(v => v != null); return { place: p, yes: votes.filter(v => v > 0).length, strongNo: votes.filter(v => v === -2).length, score: votes.reduce((a,b) => a+b, 0) }; }).sort((a,b) => a.strongNo-b.strongNo || b.yes-a.yes || b.score-a.score || a.place.title.localeCompare(b.place.title));
}
