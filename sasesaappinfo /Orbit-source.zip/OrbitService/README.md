# Orbit room service

This is the companion service for the native Orbit iPhone app. It provides temporary group rooms, host-approved browser and native guests, conversation, four-level preference ballots, and a final shared decision. The browser can create or join rooms without installing the app.

The service uses the Sites Vinext starter and a Cloudflare D1 database. `.openai/hosting.json` owns the existing Site identity and logical DB binding. Do not recreate the Site when deploying changes.

## Data and authorization

Each room has a random invitation capability and each device receives its own random member capability. Member credentials are hashed before storage. Every room read and write verifies that capability and member identifier; room content is withheld until the host approves a guest. Display names are user-chosen and are not verified identities. The host alone can approve guests, start/reopen voting, select a plan, and delete the room.

The database is authoritative. A revision compare-and-swap prevents simultaneous writes from silently replacing each other. Command IDs make retried commands idempotent within the most recent 200 operations. Chat history is bounded by count and encoded size. Rooms support eight active/pending members and twelve options.

Room access expires after seven days. Expired records are purged on the next create or join request. Hosts can delete immediately. Clients may retain local snapshots; deleting the server room does not erase other people's devices. Private photo libraries and contact books are never uploaded. Only deliberately shared place details, display names, random member identifiers, votes and messages go to the service. Short-lived hashed request-rate buckets are used for abuse limits, without raw IP storage.

Browser credentials are device-local browser storage; iPhone credentials are in Keychain. No credentials or real room data are part of the source. The invitation secret uses a URL fragment. There is no account signup, advertising, analytics, automated booking, or background push messaging.

## Local development and checks

Install the locked dependencies using the Sites install helper, generate Drizzle migrations with `npm run db:generate`, then build with the Sites build helper. Apply each generated SQL migration once to the local D1 binding using the starter README's Wrangler command. `npm run dev` starts the local preview. Production schema changes must be generated migrations; never rewrite an already applied migration.

`node tests/online-flow.mjs http://localhost:5173` exercises the real HTTP service with separate host and guest credentials, verifies access denial, approvals, simultaneous chat writes, ballot rules, shared decisions, leaving and deletion. The script creates only clearly marked synthetic data and deletes its test room. Pass the exact deployed HTTPS origin to verify a publicly reachable deployment.

`./node_modules/.bin/tsc --noEmit` checks TypeScript. The Sites build helper produces the deployable Worker and migrations. Publish the exact committed and pushed source through Sites tools, preserving the current audience unless the owner explicitly authorizes a change.
